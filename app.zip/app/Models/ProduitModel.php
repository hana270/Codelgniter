<?php

namespace App\Models;
use App\Models\CategorieModel;
use App\Models\MarqueModel;

use CodeIgniter\Model;

class ProduitModel extends Model
{
    protected $table      = 'produit';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nom', 'description', 'prix', 'reference', 'categorie_id', 'image_url', 'marque_id'];

    public function getMarqueName($marqueId)
    {
        $marqueModel = new MarqueModel();
        $marque = $marqueModel->find($marqueId);

        return $marque ? $marque['nom'] : 'Non défini';
    }

    public function getCategorieName($categorieId)
    {
        $categorieModel = new CategorieModel();
        $categorie = $categorieModel->find($categorieId);

        return $categorie ? $categorie['nom'] : 'Non défini';
    }

    public function getCategories()
    {
        // Logique pour récupérer les catégories depuis le modèle CategorieModel
        $categorieModel = new CategorieModel();
        return $categorieModel->findAll(); // Remplacez cela par votre logique réelle
    }

    public function getMarques()
    {
        // Logique pour récupérer les marques depuis le modèle MarqueModel
        $marqueModel = new MarqueModel();
        return $marqueModel->findAll(); // Remplacez cela par votre logique réelle
    }
}
