<!-- App/Views/welcome_message.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to CodeIgniter 4!</title>
    <!-- Ajoutez le lien du CDN Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2>Welcome to CodeIgniter 4!</h2>
    
    <p>This is your default homepage. You can modify this file at:</p>
    <!-- Ajoutez les liens vers les pages d'authentification -->

    
    <p><a href="<?= site_url('login/admin'); ?>" class="btn btn-primary">Admin Login</a></p>

    <p><a href="<?= site_url('login/client'); ?>" class="btn btn-secondary">Client Login</a></p>

</div>

<!-- Ajoutez le lien vers Bootstrap JS ici -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
