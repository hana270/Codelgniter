<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Modifier un Produit</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center mb-4">Modifier un Produit</h2>
    
    <form action="/produits/update/<?= $produit['id']; ?>" method="post" enctype="multipart/form-data">

        <div class="mb-3">
            <label for="nom" class="form-label">Nom du Produit :</label>
            <input type="text" class="form-control" name="nom" value="<?= $produit['nom']; ?>" required>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Description du Produit :</label>
            <textarea class="form-control" name="description" rows="4"><?= $produit['description']; ?></textarea>
        </div>

        <div class="mb-3">
            <label for="image_url" class="form-label">Image du Produit :</label>
            <?php if (!empty($produit['image_url'])): ?>
                <img src="<?= base_url('public/images/' . $produit['image_url']); ?>" alt="<?= $produit['nom']; ?>" class="img-thumbnail mb-2" width="150">
            <?php endif; ?>
            <input type="file" class="form-control" name="image_url" accept="image/*">
        </div>




        <div class="mb-3">
            <label for="prix" class="form-label">Prix du Produit :</label>
            <input type="text" class="form-control" name="prix" value="<?= $produit['prix']; ?>" required>
        </div>

        <div class="mb-3">
            <label for="reference" class="form-label">Référence du Produit :</label>
            <input type="text" class="form-control" name="reference" value="<?= $produit['reference']; ?>" required>
        </div>
        <div class="mb-3">
    <label for="marque_id" class="form-label">Marque du Produit :</label>
    <select class="form-control" name="marque_id" required>
        <?php foreach ($marques as $marque): ?>
            <option value="<?= $marque['id']; ?>" <?= ($produit['marque_id'] == $marque['id']) ? 'selected' : ''; ?>>
                <?= $marque['nom']; ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>
        <div class="mb-3">
            <label for="categorie_id" class="form-label">Catégorie du Produit :</label>
            <select class="form-control" name="categorie_id" required>
                <?php foreach ($categories as $categorie): ?>
                    <option value="<?= $categorie['id']; ?>" <?= ($produit['categorie_id'] == $categorie['id']) ? 'selected' : ''; ?>>
                        <?= $categorie['nom']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Mettre à jour</button>
    </form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-9/reFTGAWKm1Bd/BjNecv9ESw2aHQv1xLXR00m2rKbV4V2cBr4p9tSLqKDO9R5an" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy2Au2a+6QrMIVN6Pj3aLd6D5F+JjPUvXy" crossorigin="anonymous"></script>

</body>
</html>
