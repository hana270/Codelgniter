<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Liste des Produits</title>

    <!-- Ajouter le lien du CDN Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center mb-4">Liste des Produits</h2>
    <a href="/produits/create" class="" style="color: blue;">Ajouter </a>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Description</th>
                <th>Image</th>
                <th>Prix</th>
                <th>Référence</th>
                <th>Marque</th>
                <th>Catégorie</th>
                <th>Action</th> 
            </tr>
        </thead>
        <tbody>
            <?php foreach ($produits as $produit): ?>
                <tr>
                    <td><?= $produit['id']; ?></td>
                    <td><?= $produit['nom']; ?></td>
                    <td><?= $produit['description']; ?></td>

                    <td>
    <img src="<?= base_url('public/images/' . $produit['image_url']); ?>" alt="<?= $produit['nom']; ?>" class="img-thumbnail" width="100">
</td>


                    <td><?= $produit['prix']; ?></td>
                    <td><?= $produit['reference']; ?></td>

                    <td><?= $produit['marque_id']; ?></td>
        
                    <td><?= $produit['categorie_id']; ?></td>
                    <td>
                        <!-- Ajouter les liens pour edit et delete avec la confirmation -->
                        <a href="/produits/edit/<?= $produit['id']; ?>" class="btn btn-warning">Modifier</a>
                        <a href="/produits/delete/<?= $produit['id']; ?>" class="btn btn-danger" onclick="return confirmDelete();">Supprimer</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


<script>
    function confirmDelete() {
        return confirm("Voulez-vous vraiment supprimer ce produit ?");
    }
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-9/reFTGAWKm1Bd/BjNecv9ESw2aHQv1xLXR00m2rKbV4V2cBr4p9tSLqKDO9R5an" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy2Au2a+6QrMIVN6Pj3aLd6D5F+JjPUvXy" crossorigin="anonymous"></script>

</body>
</html>
