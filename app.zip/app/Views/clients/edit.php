<!-- app/Views/clients/edit.php -->
<!-- Ajouter le lien du CDN Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<h2 class="text-center mb-4">Mettre à jour un Client</h2>

<?= form_open("/clients/update/{$client['id']}", ['class' => 'container mt-5']); ?>
    <div class="mb-3">
        <label for="nom" class="form-label">Nom :</label>
        <input type="text" name="nom" class="form-control" value="<?= esc($client['nom']); ?>" required>
    </div>

    <div class="mb-3">
        <label for="prenom" class="form-label">Prénom :</label>
        <input type="text" name="prenom" class="form-control" value="<?= esc($client['prenom']); ?>" required>
    </div>

    <div class="mb-3">
        <label for="email" class="form-label">Email :</label>
        <input type="email" name="email" class="form-control" value="<?= esc($client['email']); ?>" required>
    </div>

    <div class="mb-3">
        <label for="password" class="form-label">Mot de passe :</label>
        <input type="password" name="password" class="form-control" value="<?= esc($client['password']); ?>" required>
    </div>

    <div class="mb-3">
        <label for="telephone" class="form-label">Téléphone :</label>
        <input type="text" name="telephone" class="form-control" value="<?= esc($client['telephone']); ?>" required>
    </div>

    <button type="submit" class="btn btn-primary">Mettre à jour</button>
<?= form_close(); ?>

<!-- Ajouter les scripts Bootstrap (si nécessaire) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
