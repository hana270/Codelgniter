<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <style>
        body {
            padding-top: 56px; 
        }

        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 56px;
            left: 0;
            background-color: #f8f9fa;
            padding-top: 20px;
            transition: margin-left 0.3s;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s;
        }

        .nav-link:hover {
            background-color: #343a40;
            color: #007bff;
            border-left: 3px solid #007bff;
        }

        .navbar-form {
            display: flex;
            align-items: center;
            margin-left: auto; /* Place la barre de recherche à droite */
        }

        @media (max-width: 767px) {
            .navbar-form {
                margin-top: 10px;
                margin-right: auto; /* Aligne la barre de recherche au centre sur les petits écrans */
            }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="#">Tableau de bord Admin</a>
        <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
    <li class="nav-item">
        <form class="d-flex navbar-form">
            <input class="form-control me-2" type="search" placeholder="Recherche" aria-label="Search">
            <button class="btn btn-outline-primary" type="submit"><i class="bi bi-search">search</i></button>
        </form>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?= site_url('logout'); ?>">Déconnexion</a>
    </li>

</ul>
        </div>
    </div>
</nav>

<!-- Ajoutez les liens vers Bootstrap CSS et Bootstrap Icons si nécessaire -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.19.0/font/bootstrap-icons.css" rel="stylesheet">
<!-- Sidebar -->
<div class="sidebar bg-dark">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link active text-light" href="#" onclick="loadContent('dashboard.php');">
                Tableau de bord
            </a>
        </li>
        <li class="nav-item">
        <a class="nav-link text-light" href="#" onclick="loadContent('<?= site_url('produits'); ?>');">
                Liste des Produits
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-light" href="#" onclick="loadContent('<?= site_url('clients'); ?>');">
                Liste des Clients
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-light" href="#" onclick="loadContent('<?= site_url('categories'); ?>');">
                Liste des Catégories
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-light" href="#" onclick="loadContent('liste_commandes.php');">
                Liste des Commandes
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-light" href="#" onclick="loadContent('contacts.php');">
                Contacts
            </a>
        </li>
    </ul>
</div>

<!-- Contenu principal -->
<div class="main-content">
    <iframe id="contentFrame" src="<?= site_url('dashboard.php'); ?>" class="w-100 vh-100" frameborder="0"></iframe>
</div>

<script>
    function loadContent(page) {
        document.getElementById('contentFrame').src = page;
    }
</script>


<!-- Ajoutez le lien vers Bootstrap JS ici -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-9/reFTGAWKm1Bd/BjNecv9ESw2aHQv1xLXR00m2rKbV4V2cBr4p9tSLqKDO9R5an" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy2Au2a+6QrMIVN6Pj3aLd6D5F+JjPUvXy" crossorigin="anonymous"></script>

</body>
</html>
