<!-- app/Views/categories/edit.php -->
<!-- Ajouter le lien du CDN Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<h2 class="text-center mb-4">Mettre à jour une Catégorie</h2>

<?= form_open("/categories/update/{$categorie['id']}", ['class' => 'container mt-5']); ?>
    <div class="mb-3">
        <label for="nom" class="form-label">Nom :</label>
        <input type="text" name="nom" class="form-control" value="<?= esc($categorie['nom']); ?>" required>
    </div>

    <div class="mb-3">
        <label for="description" class="form-label">Description :</label>
        <textarea name="description" class="form-control" rows="4"><?= esc($categorie['description']); ?></textarea>
    </div>

    <button type="submit" class="btn btn-primary">Mettre à jour</button>
<?= form_close(); ?>

<!-- Ajouter les scripts Bootstrap (si nécessaire) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
