<!-- Structure HTML avec Bootstrap pour créer un nouveau stock -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Stock</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-top: 50px;
        }
        .btn-primary {
            margin-top: 15px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="mb-4">Ajouter un Stock</h2>

    <form action="/stocks/store" method="post"enctype="multipart/form-data">
        <div class="mb-3">
            <label for="quantite_dispo" class="form-label">Quantité disponible</label>
            <input type="text" class="form-control" name="quantite_dispo" required>
        </div>

        <div class="mb-3">
            <label for="produit_id" class="form-label">Produit</label>
            <select class="form-select" name="produit_id" required>
                <?php foreach ($produits as $produit) : ?>
                    <option value="<?= $produit['id']; ?>"><?= $produit['nom']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>


        <button type="submit" class="btn btn-primary">Ajouter</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-9/reFTGAWKm1Bd/BjNecv9ESw2aHQv1xLXR00m2rKbV4V2cBr4p9tSLqKDO9R5an" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy2Au2a+6QrMIVN6Pj3aLd6D5F+JjPUvXy" crossorigin="anonymous"></script>

</body>
</html>
