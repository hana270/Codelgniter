<?php

if (!function_exists('getMarqueName')) {
    function getMarqueName($marqueId)
    {
        // Logique pour récupérer le nom de la marque
        // ...

        return $marque ? $marque['nom'] : 'Non défini';
    }
}

if (!function_exists('getCategorieName')) {
    function getCategorieName($categorieId)
    {
        // Logique pour récupérer le nom de la catégorie
        // ...

        return $categorie ? $categorie['nom'] : 'Non défini';
    }
}
