<?php
namespace App\Controllers;

use App\Models\ProduitModel;
use App\Models\StockModel;
use CodeIgniter\Controller;

class Stocks extends Controller
{
    public function index()
    {
        $model = new StockModel();
        $data['stocks'] = $model->findAll();

        return view('stocks/index', $data);
    }

    public function create()
{
    $modelProduit = new ProduitModel();
    $data['produits'] = $modelProduit->findAll(); 
    return view('stocks/create', $data);
}


    public function store()
    {
        helper('form');

        $model = new StockModel();
        $data = [
            'quantite_dispo' => $this->request->getPost('quantite_dispo'),
            'date_mise_a_jour' => date('Y-m-d H:i:s'),
            'produit_id' => $this->request->getPost('produit_id'),
        ];

        $model->insert($data);

        return redirect()->to('/stocks');
    }

    public function edit($id)
{
    $model = new StockModel();
    $data['stock'] = $model->find($id);

    $modelProduit = new ProduitModel();
    $produits = $modelProduit->findAll();
    $data['produits'] = $produits;

    return view('stocks/edit', $data);
}
    public function update($id)
    {
        helper('form');

        $model = new StockModel();
        $data = [
            'quantite_dispo' => $this->request->getPost('quantite_dispo'),
            'date_mise_a_jour' => date('Y-m-d H:i:s'),
            'produit_id' => $this->request->getPost('produit_id'),
        ];

        $model->update($id, $data);

        return redirect()->to('/stocks');
    }

    public function delete($id)
    {
        $model = new StockModel();
        $model->delete($id);

        return redirect()->to('/stocks');
    }
}
