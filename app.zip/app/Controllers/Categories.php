<?php

namespace App\Controllers;

use App\Models\CategorieModel; 
use CodeIgniter\Controller;

class Categories extends Controller 
{
    public function index()
    {
        $model = new CategorieModel(); 
        $data['categories'] = $model->findAll(); 

        return view('categories/index', $data); 
    }

    public function create()
    {
        return view('categories/create'); // Modifiez le nom de la vue
    }

    public function store()
    {
        helper('form');

        $model = new CategorieModel(); 
        $data = [
            'nom' => $this->request->getPost('nom'), 
            'description' => $this->request->getPost('description'), // Ajoutez le champ manquant
        ];

        $model->insert($data);

        return redirect()->to('/categories'); // Modifiez le chemin de redirection

    }

    public function edit($id)
    {
        $model = new CategorieModel(); // Utilisez le modèle approprié
        $data['categorie'] = $model->find($id); // Modifiez le nom de la variable

        return view('categories/edit', $data); // Modifiez le nom de la vue
    }

    public function update($id)
    {
        helper('form');

        $model = new CategorieModel(); // Utilisez le modèle approprié
        $data = [
            'nom' => $this->request->getPost('nom'), 
            'description' => $this->request->getPost('description'), // Ajoutez le champ manquant
        ];

        $model->update($id, $data);

        return redirect()->to('/categories'); // Modifiez le chemin de redirection
    }

    public function delete($id)
    {
        $model = new CategorieModel();
        $model->delete($id);
    
        return redirect()->to('/categories');
    }
    
}
