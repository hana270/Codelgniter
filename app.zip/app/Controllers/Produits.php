<?php

namespace App\Controllers;
helper('Produits_helper');

use App\Models\ProduitModel;
use App\Models\CategorieModel;
use App\Models\MarqueModel;
use CodeIgniter\Controller;

class Produits extends Controller 
{
   
public function create()
{
    $categorieModel = new CategorieModel();
    $marqueModel = new MarqueModel(); // Création d'une instance de MarqueModel
    $data['categories'] = $categorieModel->findAll();
    $data['marques'] = $marqueModel->findAll(); // Récupération des marques

    return view('produits/create', $data);
}

public function store()
{
    helper('form');    
    $produitModel = new ProduitModel();

    $image = $this->request->getFile('image_url');
    if ($image->isValid() && !$image->hasMoved())
    {
            $newName = $image->getRandomName();
            $image->move('public/images/', $newName);

            $data = [
                'nom' => $this->request->getPost('nom'), 
                'description' => $this->request->getPost('description'),
                'prix' => $this->request->getPost('prix'),
                'reference' => $this->request->getPost('reference'),
                'categorie_id' => $this->request->getPost('categorie_id'),
                'image_url' => $newName, 
                'marque_id' => $this->request->getPost('marque_id'), 
            ];
            $produitModel->insert($data);
            return redirect()->to('/produits');
        }
        else
        {
            return redirect()->back()->with('error', 'Veuillez sélectionner un fichier image valide.');
        }
    }

public function edit($id)
{
    $produitModel = new ProduitModel();
    $categorieModel = new CategorieModel();
    $marqueModel = new MarqueModel();
    $data['produit'] = $produitModel->find($id);
    $data['categories'] = $categorieModel->findAll();
    $data['marques'] = $marqueModel->findAll();

    return view('produits/edit', $data);
}

    public function update($id)
    {
        helper(['form', 'url']);
    
        $produitModel = new ProduitModel();
        $data = [
            'nom' => $this->request->getPost('nom'), 
            'description' => $this->request->getPost('description'),
            'prix' => $this->request->getPost('prix'),
            'reference' => $this->request->getPost('reference'),
            'categorie_id' => $this->request->getPost('categorie_id'),
        ];
    
        $image = $this->request->getFile('image_url');
    
        if ($image->isValid() && !$image->hasMoved())
        {
            // Générer un nouveau nom de fichier
            $newName = $image->getRandomName();
    
            // Déplacer le fichier téléchargé vers le dossier des images
            $image->move('public/images/', $newName);
    
            // Mettre à jour le nom de fichier dans les données
            $data['image_url'] = $newName;
        }
    
        // Mettre à jour la base de données avec les nouvelles données
        $produitModel->update($id, $data);
    
        return redirect()->to('/produits');
    }
    


    public function delete($id)
{
    echo view('produits/confirmation', ['id' => $id]);
}
// app/Controllers/Produits.php

public function confirmedDelete($id)
{
    $produitModel = new ProduitModel();
    $produitModel->delete($id);

    return redirect()->to('/produits');
}

public function index()
{
    $produitModel = new ProduitModel();
    $data = [
        'produits' => $produitModel->findAll(),
        'marques' => $produitModel->getMarques(),
        'categories' => $produitModel->getCategories(),
    ];

    // Charger le fichier d'aide produits_helper.php
    helper('Produits_helper');

    return view('produits/index', $data);
}


 

}