<?php

namespace App\Controllers;

use App\Models\ClientModel;
use CodeIgniter\Controller;

class Clients extends Controller
{
    public function login()
    {
        return view('clients/login');
    }
    public function processLogin()
    {
        $model = new ClientModel();

        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $client = $model->where('email', $email)->first();

        if ($client && password_verify($password, $client['password'])) {
            // Client authentication successful
            // You can store client information in the session if needed
            $_SESSION['client_authenticated'] = true;
            $_SESSION['client_id'] = $client['id'];
            $_SESSION['client_name'] = $client['prenom'] . ' ' . $client['nom'];

            return redirect()->to('/dashboard'); // Redirect to client dashboard or wherever needed
        } else {
            // Authentication failed
            $data['error'] = 'Invalid email or password';
            return view('login_client', $data);
        }
    }

    public function index()
    {
        $model = new ClientModel();
        $data['client'] = $model->findAll(); 

        return view('clients/index', $data);
    }

    public function create()
    {
        return view('clients/create');
    }

    public function store()
    {
        helper('form');

        $model = new ClientModel();
        $data = [
            'nom' => $this->request->getPost('nom'), 
            'email' => $this->request->getPost('email'),
            'prenom' => $this->request->getPost('prenom'), 
            'password' => $this->request->getPost('password'), 
            'telephone' => $this->request->getPost('telephone'), 
        ];

        $model->insert($data);

        return redirect()->to('/clients');

    }

    public function edit($id)
    {
        $model = new ClientModel();
        $data['client'] = $model->find($id);

        return view('clients/edit', $data);
    }

    public function update($id)
    {
        helper('form');

        $model = new ClientModel();
        $data = [
            'nom' => $this->request->getPost('nom'), 
            'email' => $this->request->getPost('email'),
            'prenom' => $this->request->getPost('prenom'), 
            'password' => $this->request->getPost('password'), 
            'telephone' => $this->request->getPost('telephone'), 
        ];

        $model->update($id, $data);

        return redirect()->to('/clients');
    }

    public function delete($id)
    {
        $model = new ClientModel();
        $model->delete($id);

        return redirect()->to('/client');
    }
}
