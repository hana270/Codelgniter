<?php

namespace App\Controllers;

use Config\View;

class Home extends BaseController
{
    public function index(): string
    {
        return view('welcome_message.php');
    }
    public function admin(): String
    {
        return view('Admin_template/indexx');
    }
}
